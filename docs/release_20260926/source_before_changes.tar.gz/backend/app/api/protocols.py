from __future__ import annotations

from fastapi import APIRouter, HTTPException

from ..protocol import get_protocol, list_protocols, load_body_regions, validate_protocol_text
from . import schemas as S

router = APIRouter(prefix="/api", tags=["protocol"])


@router.get("/protocols")
def protocols():
    return list_protocols()


@router.get("/protocols/{protocol_id}")
def protocol_detail(protocol_id: str):
    try:
        p = get_protocol(protocol_id)
    except FileNotFoundError:
        raise HTTPException(404, "协议不存在")
    return {**p.model_dump(), "review_gaps": p.review_gaps()}


@router.post("/protocols/validate")
def validate(body: S.ProtocolValidateIn):
    return validate_protocol_text(body.yaml_text)


@router.get("/body-regions")
def body_regions():
    return load_body_regions()
