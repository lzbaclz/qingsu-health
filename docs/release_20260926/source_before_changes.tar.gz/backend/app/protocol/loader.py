from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import yaml
from pydantic import ValidationError

from ..config import settings
from .schema import Protocol


def _protocol_path(protocol_id: str) -> Path:
    return settings.protocol_dir / f"{protocol_id}.yaml"


@lru_cache(maxsize=32)
def get_protocol(protocol_id: str) -> Protocol:
    path = _protocol_path(protocol_id)
    if not path.exists():
        raise FileNotFoundError(f"协议不存在: {path}")
    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    return Protocol.model_validate(data)


def list_protocols() -> list[dict]:
    out = []
    for p in sorted(settings.protocol_dir.glob("*.yaml")):
        if p.stem == "body_regions":
            continue
        try:
            proto = get_protocol(p.stem)
            out.append({
                "protocol_id": proto.protocol_id, "version": proto.version, "status": proto.status,
                "title": proto.title, "specialty": proto.specialty,
                "facts": len(proto.facts), "questions": len(proto.questions), "red_flags": len(proto.red_flags),
                "review_gaps": len(proto.review_gaps()),
            })
        except Exception as e:  # noqa: BLE001
            out.append({"protocol_id": p.stem, "error": str(e)})
    return out


def validate_protocol_text(text: str) -> dict:
    """供 /api/protocols/validate 使用：医生改完 YAML 立刻知道哪里不合法。"""
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as e:
        return {"ok": False, "errors": [f"YAML 解析失败: {e}"]}
    try:
        proto = Protocol.model_validate(data)
    except ValidationError as e:
        return {"ok": False, "errors": [f"{'.'.join(str(x) for x in err['loc'])}: {err['msg']}" for err in e.errors()]}
    return {"ok": True, "errors": [], "protocol_id": proto.protocol_id, "version": proto.version,
            "review_gaps": proto.review_gaps()}


@lru_cache(maxsize=1)
def load_body_regions() -> list[dict]:
    path = settings.protocol_dir / "body_regions.yaml"
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)["regions"]


def region_index() -> dict[str, dict]:
    return {r["id"]: r for r in load_body_regions()}
