"""任务、通知、审计：状态由人推进，系统只创建。"""
from __future__ import annotations

from sqlmodel import Session, select

from ..models import AuditLog, Notification, NotificationStatus, Task, TaskStatus
from ..util import iso, now


class TransitionError(ValueError):
    pass


def audit(session: Session, actor: str, action: str, target_type: str, target_id: str, detail: dict | None = None) -> AuditLog:
    log = AuditLog(actor=actor, action=action, target_type=target_type, target_id=target_id, detail=detail or {})
    session.add(log)
    session.commit()
    session.refresh(log)
    return log


def create_task(session: Session, encounter_id: str, kind: str, title: str, alert_id: str | None = None) -> Task:
    t = Task(encounter_id=encounter_id, kind=kind, title=title, alert_id=alert_id,
             history=[{"to": TaskStatus.UNVIEWED, "by": "system", "at": iso(now()), "note": "系统创建"}])
    session.add(t)
    session.commit()
    session.refresh(t)
    return t


def transition_task(session: Session, task: Task, to: str, actor: str, note: str | None = None) -> Task:
    if to not in TaskStatus.TRANSITIONS.get(task.status, set()):
        raise TransitionError(f"任务不能从 {task.status} 变为 {to}")
    if not actor or actor == "system":
        raise TransitionError("任务状态只能由人推进")
    task.status = to
    task.assignee = task.assignee or actor
    task.history = task.history + [{"to": to, "by": actor, "at": iso(now()), "note": note}]
    task.updated_at = now()
    session.add(task)
    session.commit()
    session.refresh(task)
    audit(session, actor, f"task.{to}", "task", task.id, {"note": note})
    return task


def create_notification(session: Session, encounter_id: str, content: str, by: str, channel: str = "in_app") -> Notification:
    n = Notification(encounter_id=encounter_id, content=content, channel=channel,
                     history=[{"to": NotificationStatus.QUEUED, "by": by, "at": iso(now())}])
    session.add(n)
    session.commit()
    session.refresh(n)
    return n


def transition_notification(session: Session, n: Notification, to: str, by: str) -> Notification:
    if to not in NotificationStatus.TRANSITIONS.get(n.status, set()):
        raise TransitionError(f"通知不能从 {n.status} 变为 {to}")
    if to in (NotificationStatus.SEEN, NotificationStatus.ACKNOWLEDGED) and not by.startswith("patient"):
        raise TransitionError("已看到/已确认只能由患者端记录")
    n.status = to
    n.history = n.history + [{"to": to, "by": by, "at": iso(now())}]
    session.add(n)
    session.commit()
    session.refresh(n)
    return n


def deliver_queued(session: Session, encounter_id: str) -> list[Notification]:
    """演示用的发送通道：把 queued 标为 sent。真实部署接短信/公众号时替换这里。"""
    out = []
    for n in session.exec(select(Notification).where(Notification.encounter_id == encounter_id,
                                                     Notification.status == NotificationStatus.QUEUED)).all():
        out.append(transition_notification(session, n, NotificationStatus.SENT, "system:channel_demo"))
    return out


def task_to_dict(t: Task) -> dict:
    return {"id": t.id, "encounter_id": t.encounter_id, "alert_id": t.alert_id, "kind": t.kind, "title": t.title,
            "status": t.status, "assignee": t.assignee, "history": t.history,
            "allowed_transitions": sorted(TaskStatus.TRANSITIONS.get(t.status, set())),
            "created_at": iso(t.created_at), "updated_at": iso(t.updated_at), **_course_extra(t)}


def _course_extra(t: Task) -> dict:
    from ..course.tasks import task_extra  # 避免循环导入
    return task_extra(t)


def notification_to_dict(n: Notification) -> dict:
    return {"id": n.id, "encounter_id": n.encounter_id, "channel": n.channel, "content": n.content, "status": n.status,
            "history": n.history, "created_at": iso(n.created_at)}
