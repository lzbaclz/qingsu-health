# 体迹 AI（TiJi AI）

> 面向专科门诊的 AI 症状表达与病程协作工具。
> 患者用身体地图 + 自己的话在见医生前把症状说清楚；系统按**医生定义的临床协议**补问、让患者确认事实；
> 医生看到**每一条都能点回原话**的摘要、缺口、矛盾和需要人处理的事项；诊后随访只呈现"相比上次变了什么"。

德邻杯 2026 参赛项目 · 首个示范场景：成年腰背痛（协议为工程占位，**待临床队友审核**）。

## 这不是什么
- 不是诊断工具：不输出病名、不给治疗或用药建议（系统生成的文字会被越界检查拦截）。
- 不是"给大模型套一个 3D 人"：模型只做两件事——从口语中抽取协议定义的事实（带原话引用）、把已整理的事实写成两三句叙述。**问什么、何时升级、给患者看什么，全部由协议决定。**
- 不替代医生接诊：医生仍独立问诊、检查、判断；产品只减少"表达不清、整理遗漏、异常无人接手"。

## 目录
```
protocols/            临床协议（医生填写的 YAML）+ 身体区域定义 + 医生工作表模板
backend/              FastAPI 后端：事实状态库、问询引擎、抽取、摘要、验收检查、任务/通知
frontend/             Vite + React：患者端（手机）/p，医生端（桌面）/d
eval/                 离线场景评测：80 个模拟场景（40 开发 / 40 锁定）+ 运行器 + 报告
docs/                 产品框架、架构、数据模型、协议规范、验证方案、合规边界、七日计划、医生任务清单、BP 大纲
```

## 快速开始
```bash
make setup        # uv + pnpm 安装依赖（需要 uv、pnpm、Python≥3.11、Node≥20）
make backend      # http://localhost:8000  （API 文档 http://localhost:8000/docs）
make seed         # 灌入演示路径：正常 / 矛盾澄清 / 紧急终止 / 随访
make frontend     # http://localhost:5173  → 首页选 患者端 或 医生端；膝痛示范：/p?protocol=knee_adult_v0.1
make test         # 后端测试（54 项）
make eval         # 80 场景（离线词表）      make eval-stress  # 20 句口语压力集
make llm-check    # 真实模型连通性自检（先跑它）
make eval-real    # 真实模型 Claude（需 ANTHROPIC_API_KEY）  make eval-cn  # 国产模型（需 TIJI_COMPAT_*）
make eval-careless  # 粗心患者对照（核对一律点"对"）   make evidence  # 重新生成 BP 证据表
make user-test-backend  # 10 人测试专用后端（卡 A 显眼型、卡 B 隐蔽型植入错抽；默认离线词表；演示与录视频不要用）
make protocol-check   # 医生改完协议 YAML 后校验
make protocol-v02     # 按 protocols/review/decisions.yaml 生成协议 v0.2 候选（医生决定前只是 AI 草案，不对外使用）
make user-test-report # 汇总 UT- 开头的可用性测试记录
```
默认 `TIJI_LLM_PROVIDER=mock`：确定性关键词抽取，离线可跑、结果可复现，用作评测基线与演示兜底。
真实模型：复制 `backend/.env.example` 为 `backend/.env`，设 `TIJI_LLM_PROVIDER=anthropic`（官方 SDK、结构化输出、服务端拒答回退）或 `compat`（DeepSeek / 通义千问 / 智谱等 OpenAI 兼容接口）。真实模型失败时自动退回离线词表并在界面标注。

## 核心设计（一句话版）
| 原则 | 在代码里的落点 |
|---|---|
| 未问 ≠ 没有 | 事实六种状态：present / denied / not_asked / asked_unanswered / uncertain / conflicting（`backend/app/models.py`） |
| 每条事实可回溯 | `Fact.evidence[{entry_id, quote}]`，quote 必须逐字来自原始记录（验收 V3） |
| 矛盾不自动取其一 | `facts/store.py` 进入 conflicting → 问询引擎先出澄清题；未澄清不能确认 |
| 模型不决定流程 | 问询、红旗、宣教全在 `protocols/*.yaml`；`llm/provider.py` 只做抽取与叙述 |
| 修改留版本 | Fact 版本链 + Summary 版本 + AuditLog |
| 任务由人推进 | `tasks/service.py`：系统只能创建任务，completed 必须有人 |
| 发送 ≠ 看到 ≠ 理解 | Notification：queued → sent → seen → acknowledged，后两步只能由患者端记录 |
| 系统自证 | `verification/checks.py` 九项检查（出处、不补全、引文、越界、矛盾、红旗、通知、版本、确认顺序） |

## 当前状态（2026-09-25，第三轮对抗式评审修改后）
- 已完成：后端全流程（一键核对、紧急红旗终止问询、开始页适用范围确认）、患者端 / 医生端（按紧急程度排序的列表、接诊速览、病历初稿、给患者说明的改写、打印导出、模型标识与自检、患者原话标记）、协议示例与 AI 模拟医生填写版、v0.2 候选生成工具与医生两小时决定表、评测运行器（三层口径：模型刚读完 / 粗心患者 / 认真患者）+ 80 场景 + 20 句口语压力集、三种模型适配与"任何异常都退回离线词表"、可用性测试埋点、植入错抽与汇总、第二专科（膝痛）复用示范、BP v1.2（无红字占位）与逐页文案。第三轮评审后：患者原话提到、核对时又否认的红旗不再写成"否认"，按原级别排序并标"待电话核实"；给患者的说明默认按医生审定的术语对照表整理、不调用模型，开启模型改写时要点以外的新内容发送前被拦下并加 AI 标注；读原话与只发问卷改用同一位如实作答的模拟患者对照；植入错抽分显眼型与隐蔽型。后端测试 54 项。
- 离线词表基线（场景未经临床审核，只是开发基线）：80 场景认真患者与粗心患者都无关键错误；压力集抽取层漏抽 21 · 编造 2 · 错抽 4 · 红旗漏识别 5，认真患者 20/20、粗心患者 17/20 无关键错误。证据表 `eval/results/证据表.md`（`make evidence`）。
- 需要人完成：医生决定会（实名 + 18 条红旗 + 5 个新决定 + 适用范围 + 题数，约 2 小时 15 分钟）、至少 1 家门诊电话访谈、补模型 key 跑真实模型评测、10 人测试（含两种植入错抽）、视频、提交。医生要做的事见 `docs/08`；逐项与止损规则见 `docs/16` 末尾"处理进度"与 `docs/07`。

详细文档见 `docs/`，从 `docs/01_产品框架.md` 开始；医生队友请直接看 `docs/08_医生任务清单.md`；本周安排看 `docs/07`；BP 文案看 `docs/11`。
