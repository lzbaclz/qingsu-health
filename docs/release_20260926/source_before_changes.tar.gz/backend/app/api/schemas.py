from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field


class CreateEncounterIn(BaseModel):
    patient_code: Optional[str] = None
    protocol_id: Optional[str] = None
    kind: str = "pre_visit"
    parent_encounter_id: Optional[str] = None
    eligibility: Optional[dict[str, bool]] = None  # 开始页适用范围确认（协议 scope.eligibility 的 id → 是否符合）
    respondent: str = "self"                 # self 本人 | family 家属代述 | staff 前台代录
    respondent_relation: Optional[str] = None
    proxy_consent: bool = False              # 代填时患者本人在场并同意


class BodyMapMark(BaseModel):
    region_id: str
    kind: str = Field(default="primary", pattern="^(primary|radiation)$")
    intensity: Optional[int] = None


class BodyMapIn(BaseModel):
    marks: list[BodyMapMark]


class TextIn(BaseModel):
    text: str


class AnswerIn(BaseModel):
    question_id: str
    value: Any = None
    unknown: bool = False
    skipped: bool = False


class Correction(BaseModel):
    fact_key: str
    status: str = "present"
    value: Any = None


class ConfirmIn(BaseModel):
    corrections: list[Correction] = Field(default_factory=list)


class NotificationEventIn(BaseModel):
    event: str = Field(pattern="^(seen|acknowledged)$")


class SummaryEditIn(BaseModel):
    actor: str
    edits: dict[str, str]
    note: Optional[str] = None


class FactCorrectionIn(BaseModel):
    actor: str
    key: str
    status: str
    value: Any = None
    note: str


class DoctorConfirmIn(BaseModel):
    actor: str
    override_reason: Optional[str] = None


class FollowupPlanIn(BaseModel):
    actor: str
    interval_days: Optional[int] = None
    watch_facts: Optional[list[str]] = None
    patient_message: str
    drafted_with: Optional[str] = None  # 说明由 AI 按医生要点改写过时，记下用的模型（审计用）
    draft_id: Optional[str] = None      # 由"改写"起草时的草稿编号：发送前据此复查要点以外的新内容
    override_reason: Optional[str] = None  # 确需保留要点以外的内容时，医生写的理由（记入审计）


class FollowupDraftIn(BaseModel):
    actor: str
    notes: str                          # 医生要点，可以简写
    interval_days: Optional[int] = None


class TaskTransitionIn(BaseModel):
    actor: str
    to: str
    note: Optional[str] = None
    closure: Optional[dict] = None  # 红旗任务结案的处置记录：reached / attempts / advice / reason / note


class ProtocolValidateIn(BaseModel):
    yaml_text: str


class UsageEventIn(BaseModel):
    type: str
    payload: dict[str, Any] = Field(default_factory=dict)
    client_ts: Optional[str] = None
