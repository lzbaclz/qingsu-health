import os
import tempfile

os.environ["TIJI_DATABASE_URL"] = f"sqlite:///{tempfile.mkdtemp(prefix='tiji_test_')}/test.db"
os.environ["TIJI_LLM_PROVIDER"] = "mock"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.db import init_db, session_scope  # noqa: E402
from app.main import app  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def _db():
    init_db()


@pytest.fixture()
def session():
    with session_scope() as s:
        yield s


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c
