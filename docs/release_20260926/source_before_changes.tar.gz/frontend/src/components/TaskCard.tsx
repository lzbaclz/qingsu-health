import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { doctorApi, errorMessage } from '../api/client'
import type { ClosureSpec, Task, TaskStatus } from '../api/types'
import { TASK_KIND, TASK_STATUS, fmtTime, lbl } from '../labels'
import { ErrorBox } from './Boxes'
import { Tag, TaskStatusTag } from './Tag'

const TRANSITION_VERB: Record<TaskStatus, string> = {
  unviewed: '标记未查看',
  viewed: '标记已查看',
  contacted: '已联系患者',
  pending: '待进一步处理',
  escalated: '升级',
  completed: '完成',
}

export function TaskCard({
  task,
  actor,
  onChanged,
  showEncounter = false,
}: {
  task: Task
  actor: string
  onChanged: () => void
  showEncounter?: boolean
}) {
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showHistory, setShowHistory] = useState(false)
  // 红旗任务结案：必须填处置记录（联系上没有、给了什么建议）；联系不上要至少两次尝试
  const [closing, setClosing] = useState(false)
  const [spec, setSpec] = useState<ClosureSpec | null>(null)
  const [reached, setReached] = useState('')
  const [attempts, setAttempts] = useState(1)
  const [advice, setAdvice] = useState('')
  const [reason, setReason] = useState('')

  useEffect(() => {
    if (closing && !spec) {
      doctorApi
        .closureSpec(task.encounter?.protocol_id)
        .then(setSpec)
        .catch((e) => setError(errorMessage(e)))
    }
  }, [closing, spec, task.encounter?.protocol_id])

  async function go(to: TaskStatus) {
    if (to === 'completed' && task.needs_closure && !closing) {
      setClosing(true)
      return
    }
    setBusy(true)
    setError(null)
    try {
      await doctorApi.transition(task.id, {
        actor,
        to,
        note: note.trim() || undefined,
        closure: to === 'completed' && task.needs_closure ? { reached, attempts, advice: advice || undefined, reason: reason.trim() || undefined } : undefined,
      })
      setNote('')
      setClosing(false)
      onChanged()
    } catch (e) {
      setError(errorMessage(e))
    } finally {
      setBusy(false)
    }
  }

  const reachedOpt = spec?.reached.options.find((o) => o.value === reached)
  const adviceOpt = spec?.advice.options.find((o) => o.value === advice)

  return (
    <div className={`task-card status-${task.status}${task.overdue ? ' overdue' : ''}`}>
      <div className="row wrap">
        <TaskStatusTag status={task.status} />
        <Tag tone="gray">{lbl(TASK_KIND, task.kind)}</Tag>
        {task.overdue && <Tag tone="red">已超时</Tag>}
      </div>
      <div className="task-title">{task.title}</div>
      {Boolean(task.assignee_role_label || task.due_local || task.detail?.due_label) && (
        <div className="task-due">
          {task.assignee_role_label ?? '未派'} · {task.due_local ? `${task.due_local} 前` : String(task.detail?.due_label ?? '')}
          {task.due_local && task.detail?.due_label ? `（${String(task.detail.due_label)}）` : ''}
        </div>
      )}
      {typeof task.detail?.slip_line === 'string' && <div className="task-slip">{task.detail.slip_line}</div>}
      {task.closure && (
        <div className="small task-closure">
          结案记录：{task.closure.reached_label}
          {task.closure.attempts > 1 ? `（尝试 ${task.closure.attempts} 次）` : ''}
          {task.closure.advice_label ? ` · ${task.closure.advice_label}` : ''}
          {task.closure.reason ? ` · 理由：${task.closure.reason}` : ''} · {task.closure.by}
        </div>
      )}
      {showEncounter && (
        <div className="small">
          患者 <span className="mono strong">{task.encounter?.patient_code ?? '—'}</span> ·{' '}
          <Link to={`/d/e/${task.encounter_id}`}>查看就诊</Link>
        </div>
      )}
      <div className="small muted">
        负责人：{task.assignee ?? '未分配'} · 创建 {fmtTime(task.created_at)}
      </div>
      <button type="button" className="link-btn small" onClick={() => setShowHistory((s) => !s)}>
        {showHistory ? '收起历史' : `历史（${task.history.length}）`}
      </button>
      {showHistory && (
        <ul className="history small">
          {task.history.map((h, i) => (
            <li key={i}>
              {fmtTime(h.at)} · {h.by} → {lbl(TASK_STATUS, h.to)}
              {h.note ? `（${h.note}）` : ''}
            </li>
          ))}
        </ul>
      )}
      {task.allowed_transitions.length > 0 && (
        <div className="task-actions">
          <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="备注（可选）" className="input-sm" />
          <div className="row wrap">
            {task.allowed_transitions.map((t) => (
              <button
                key={t}
                type="button"
                className={`btn btn-sm ${t === 'completed' ? 'btn-primary' : t === 'escalated' ? 'btn-danger' : 'btn-secondary'}`}
                disabled={busy}
                onClick={() => go(t)}
              >
                {TRANSITION_VERB[t]}
              </button>
            ))}
          </div>
        </div>
      )}
      {closing && (
        <div className="closure-form">
          <strong>结案前填写处置记录</strong>
          {!spec ? (
            <p className="small muted">正在加载…</p>
          ) : (
            <>
              <div className="stack-sm">
                <span className="small muted">联系上没有？</span>
                <div className="row wrap">
                  {spec.reached.options.map((o) => (
                    <button key={o.value} type="button" className={`btn btn-sm ${reached === o.value ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setReached(o.value)}>
                      {o.label}
                    </button>
                  ))}
                </div>
                {reachedOpt?.unreached && (
                  <label className="small">
                    已尝试
                    <input type="number" min={1} max={9} value={attempts} onChange={(e) => setAttempts(Number(e.target.value) || 1)} className="input-xs" /> 次
                    （至少 {spec.reached.min_attempts_if_unreached ?? 2} 次才能结案，时间写在备注里）
                  </label>
                )}
              </div>
              {reached && !reachedOpt?.unreached && (
                <div className="stack-sm">
                  <span className="small muted">给了什么建议？</span>
                  <div className="row wrap">
                    {spec.advice.options.map((o) => (
                      <button key={o.value} type="button" className={`btn btn-sm ${advice === o.value ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setAdvice(o.value)}>
                        {o.label}
                      </button>
                    ))}
                  </div>
                  {adviceOpt?.requires_reason && (
                    <input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="写明理由（必填）" className="input-sm" />
                  )}
                </div>
              )}
              <div className="row">
                <button type="button" className="btn btn-sm btn-primary" disabled={busy || !reached} onClick={() => go('completed')}>
                  确认结案
                </button>
                <button type="button" className="btn btn-sm btn-ghost" onClick={() => setClosing(false)}>
                  取消
                </button>
              </div>
            </>
          )}
        </div>
      )}
      {task.status === 'completed' && <div className="small muted">已完成，无后续流转。</div>}
      <ErrorBox error={error} onClose={() => setError(null)} />
    </div>
  )
}
