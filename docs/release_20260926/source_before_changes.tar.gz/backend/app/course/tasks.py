"""任务派发、时限与结案（第 1 轮团队评审 · 医学 / 工业设计）：每件事有人接、几点前、怎么结案都有记录。

- 派给哪个角色、几点前处理，按协议 course.task_routing 与门诊服务时段计算；协议没写时不派、不设时限（v0.1）。
- 停诊时段触发的紧急 / 当天红旗：额外建一条"次日开门第一件：回访是否已就诊"。
- 红旗任务"已完成"前必须填处置记录：联系上没有、给了什么建议、谁处理；联系不上要至少两次尝试。
- 到期未签到（随访计划到期后仍没有新的签到）：建"电话回访"任务，只建一次。
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from sqlmodel import Session, select

from ..models import Encounter, Task, TaskStatus
from ..protocol.schema import Protocol
from ..tasks.service import TransitionError, audit, create_task
from ..util import iso, now
from .hours import end_of_today, in_service_hours, local_now, next_open, tz

ROLE_LABEL = {"frontdesk": "前台", "nurse": "护士", "therapist": "治疗师", "doctor": "医生"}
CLOSURE_KINDS = {"red_flag_review", "after_hours_callback"}

# 协议没写结案表单时的保守默认（与模拟临床稿同义）
DEFAULT_CLOSURE = {
    "reached": {"options": [{"value": "reached", "label": "已联系上患者或家属"},
                            {"value": "unreached", "label": "没联系上", "unreached": True}],
                "min_attempts_if_unreached": 2},
    "advice": {"options": [{"value": "go_ed_now", "label": "请立即去急诊 / 已帮忙叫 120"},
                           {"value": "come_today", "label": "请今天来门诊"},
                           {"value": "already_seen", "label": "患者已在急诊或医院就诊"},
                           {"value": "not_urgent_by_doctor", "label": "医生判断无需紧急处理", "requires_reason": True}]},
}


def _due(protocol: Protocol, route_key: str, at: datetime) -> tuple[str | None, datetime | None, str | None]:
    """返回 (负责角色, 截止时间, 时限说明)。"""
    tr = protocol.course.task_routing.get(route_key)
    if tr is None:
        return None, None, None
    open_now = in_service_hours(protocol, at)
    if route_key == "urgent":
        if open_now is not False:
            m = tr.due_minutes_in_hours or 30
            return tr.assignee_role, at + timedelta(minutes=m), f"收到后 {m} 分钟内"
        nxt = next_open(protocol, at)
        return tr.assignee_role, (nxt + timedelta(minutes=30)) if nxt else None, "下一个开诊时段开门后 30 分钟内"
    if route_key == "same_day":
        if open_now is not False:
            eod = end_of_today(protocol, at)
            return tr.assignee_role, eod, "今天停诊前"
        nxt = next_open(protocol, at)
        return tr.assignee_role, (nxt + timedelta(hours=2)) if nxt else None, "下一个开诊日上午"
    if tr.due_days:
        return tr.assignee_role, at + timedelta(days=tr.due_days), f"{tr.due_days} 天内"
    if route_key == "recovery" or tr.due == "before_next_session":
        return tr.assignee_role, None, "下次治疗前"
    return tr.assignee_role, None, None


def create_routed_task(session: Session, protocol: Protocol, encounter_id: str, kind: str, title: str, *,
                       severity: str | None = None, route_key: str | None = None, alert_id: str | None = None,
                       assignee_role: str | None = None, due_at: datetime | None = None, detail: dict | None = None) -> Task:
    t = create_task(session, encounter_id, kind, title, alert_id=alert_id)
    role, due, due_label = _due(protocol, route_key or severity or "routine", now())
    t.assignee_role = assignee_role or role
    t.due_at = due_at or due
    t.severity = severity
    t.detail = {**(detail or {}), **({"due_label": due_label} if due_label and not due_at else {})}
    session.add(t)
    session.commit()
    session.refresh(t)
    return t


def after_hours_callback(session: Session, protocol: Protocol, encounter_id: str, alert) -> Task | None:
    """停诊时段触发的紧急 / 当天红旗：患者端已被引导去急诊；门诊下一个开诊时段第一件事回访结果。"""
    if alert.severity not in ("urgent", "same_day") or in_service_hours(protocol) is not False:
        return None
    spec = protocol.course.callback_task
    nxt = next_open(protocol)
    due = nxt + timedelta(minutes=spec.due_minutes_after_open) if nxt else None
    return create_routed_task(session, protocol, encounter_id, "after_hours_callback", spec.title, severity=alert.severity,
                              alert_id=alert.id, assignee_role=spec.assignee_role, due_at=due,
                              detail={"rule_label": alert.label, "triggered_local": local_now().strftime("%m-%d %H:%M"),
                                      "due_label": "下一个开诊时段开门后 %d 分钟内" % spec.due_minutes_after_open})


def closure_spec(protocol: Protocol) -> dict:
    return protocol.course.closure or DEFAULT_CLOSURE


def validate_closure(protocol: Protocol, closure: dict | None) -> dict:
    """红旗任务结案的处置记录。不合格抛 TransitionError（界面显示原因）。"""
    if not isinstance(closure, dict):
        raise TransitionError("红旗任务结案前，请填写处置记录：联系上没有、给了什么建议")
    spec = closure_spec(protocol)
    r_opts = {o["value"]: o for o in (spec.get("reached") or {}).get("options", [])}
    a_opts = {o["value"]: o for o in (spec.get("advice") or {}).get("options", [])}
    reached = closure.get("reached")
    if reached not in r_opts:
        raise TransitionError("请选择是否联系上患者")
    attempts = int(closure.get("attempts") or 1)
    need = int((spec.get("reached") or {}).get("min_attempts_if_unreached") or 2)
    if r_opts[reached].get("unreached") and attempts < need:
        raise TransitionError(f"没联系上时，至少尝试 {need} 次（写明时间）才能结案；否则请保持任务打开")
    advice = closure.get("advice")
    if not r_opts[reached].get("unreached"):
        if advice not in a_opts:
            raise TransitionError("请选择给患者的建议")
        if a_opts[advice].get("requires_reason") and not str(closure.get("reason") or "").strip():
            raise TransitionError("选择这一项需要写明理由")
    out = {"reached": reached, "reached_label": r_opts[reached].get("label"), "attempts": attempts,
           "advice": advice if advice in a_opts else None, "advice_label": a_opts.get(advice, {}).get("label"),
           "reason": (closure.get("reason") or "").strip() or None, "note": (closure.get("note") or "").strip() or None,
           "outcome_followup": closure.get("outcome_followup")}
    return out


def complete_with_closure(session: Session, protocol: Protocol, task: Task, actor: str, closure: dict | None, note: str | None) -> Task:
    from ..tasks.service import transition_task

    rec = validate_closure(protocol, closure) if task.kind in CLOSURE_KINDS else (closure or None)
    if rec is not None:
        task.closure = {**rec, "by": actor, "at": iso(now())}
        session.add(task)
        session.commit()
    t = transition_task(session, task, TaskStatus.COMPLETED, actor, note)
    if rec is not None:
        audit(session, actor, "task.closure", "task", task.id, task.closure or {})
    return t


def is_overdue(t: Task) -> bool:
    if t.due_at is None or t.status == TaskStatus.COMPLETED:
        return False
    due = t.due_at if t.due_at.tzinfo else t.due_at.replace(tzinfo=timezone.utc)
    return due < now()


def task_extra(t: Task) -> dict[str, Any]:
    """任务卡上的"谁 · 几点前"。"""
    due_local = None
    if t.due_at is not None:
        due = t.due_at if t.due_at.tzinfo else t.due_at.replace(tzinfo=timezone.utc)
        due_local = due.astimezone(tz()).strftime("%m-%d %H:%M")
    return {"assignee_role": t.assignee_role, "assignee_role_label": ROLE_LABEL.get(t.assignee_role or "", None),
            "severity": t.severity, "due_at": iso(t.due_at), "due_local": due_local, "overdue": is_overdue(t),
            "detail": t.detail, "closure": t.closure, "needs_closure": t.kind in CLOSURE_KINDS}


def sweep_no_response(session: Session) -> list[Task]:
    """到期未签到：医生设了随访计划，到期后超过 hours_after_due 仍没有新的签到 → 建一次"电话回访"任务。
    在医生端列表 / 任务页加载时调用（幂等），不需要后台定时器。"""
    from ..protocol import get_protocol

    made = []
    encs = session.exec(select(Encounter).where(Encounter.followup_plan.is_not(None))).all()  # type: ignore[union-attr]
    for e in encs:
        plan = e.followup_plan or {}
        try:
            protocol = get_protocol(e.protocol_id)
        except Exception:  # noqa: BLE001
            continue
        rule = protocol.course.no_response
        if rule is None or not plan.get("set_at"):
            continue
        set_at = datetime.fromisoformat(str(plan["set_at"]).replace("Z", "+00:00"))
        due = set_at + timedelta(days=int(plan.get("interval_days") or protocol.followup.default_interval_days))
        if now() < due + timedelta(hours=rule.hours_after_due):
            continue
        kids = session.exec(select(Encounter).where(Encounter.parent_encounter_id == e.id)).all()
        if any((k.created_at if k.created_at.tzinfo else k.created_at.replace(tzinfo=timezone.utc)) >= set_at for k in kids):
            continue
        if session.exec(select(Task).where(Task.encounter_id == e.id, Task.kind == "no_response")).first():
            continue
        made.append(create_routed_task(session, protocol, e.id, "no_response", rule.title, severity="routine",
                                       route_key="routine", assignee_role=rule.assignee_role,
                                       detail={"due_was": iso(due), "hours_after_due": rule.hours_after_due}))
    return made
