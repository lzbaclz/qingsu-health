from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select

from ..config import settings
from ..db import get_session
from ..models import Notification, NotificationStatus
from ..services import encounter as svc
from ..tasks.service import TransitionError, transition_notification
from . import schemas as S

router = APIRouter(prefix="/api/patient", tags=["patient"])


def _enc(session: Session, encounter_id: str):
    try:
        return svc.get_encounter(session, encounter_id)
    except svc.FlowError as e:
        raise HTTPException(404, str(e))


def _run(fn, *a, **kw):
    try:
        return fn(*a, **kw)
    except svc.FlowError as e:
        raise HTTPException(400, str(e))
    except TransitionError as e:
        raise HTTPException(409, str(e))


@router.post("/encounters")
def create_encounter(body: S.CreateEncounterIn, session: Session = Depends(get_session)):
    enc = _run(svc.create_encounter, session, patient_code=body.patient_code,
               protocol_id=body.protocol_id or settings.default_protocol_id, kind=body.kind,
               parent_encounter_id=body.parent_encounter_id, eligibility=body.eligibility, require_eligibility=True,
               respondent=body.respondent, respondent_relation=body.respondent_relation, proxy_consent=body.proxy_consent)
    return svc.patient_state(session, enc)


@router.get("/encounters/{encounter_id}")
def get_state(encounter_id: str, session: Session = Depends(get_session)):
    return svc.patient_state(session, _enc(session, encounter_id))


@router.post("/encounters/{encounter_id}/body-map")
def body_map(encounter_id: str, body: S.BodyMapIn, session: Session = Depends(get_session)):
    enc = _enc(session, encounter_id)
    return _run(svc.add_body_map, session, enc, [m.model_dump() for m in body.marks])


@router.post("/encounters/{encounter_id}/text")
def free_text(encounter_id: str, body: S.TextIn, session: Session = Depends(get_session)):
    enc = _enc(session, encounter_id)
    return _run(svc.add_text, session, enc, body.text)


@router.get("/encounters/{encounter_id}/next-question")
def next_question(encounter_id: str, session: Session = Depends(get_session)):
    enc = _enc(session, encounter_id)
    q = svc.get_next_question(session, enc)
    session.refresh(enc)
    return {"question": q, "status": enc.status, "question_count": enc.question_count,
            "notices": svc.active_notices(session, enc), **svc.stop_info(session, enc)}


@router.post("/encounters/{encounter_id}/answer")
def answer(encounter_id: str, body: S.AnswerIn, session: Session = Depends(get_session)):
    enc = _enc(session, encounter_id)
    res = _run(svc.answer_question, session, enc, body.question_id, value=body.value, unknown=body.unknown, skipped=body.skipped)
    q = svc.get_next_question(session, enc)
    session.refresh(enc)
    return {**res, "next": q, "status": enc.status, "question_count": enc.question_count, **svc.stop_info(session, enc)}


@router.get("/encounters/{encounter_id}/confirmation")
def confirmation(encounter_id: str, session: Session = Depends(get_session)):
    return svc.confirmation_view(session, _enc(session, encounter_id))


@router.post("/encounters/{encounter_id}/confirm")
def confirm(encounter_id: str, body: S.ConfirmIn, session: Session = Depends(get_session)):
    enc = _enc(session, encounter_id)
    return _run(svc.patient_confirm, session, enc, [c.model_dump() for c in body.corrections])


@router.post("/encounters/{encounter_id}/notifications/{notification_id}/event")
def notification_event(encounter_id: str, notification_id: str, body: S.NotificationEventIn, session: Session = Depends(get_session)):
    n = session.get(Notification, notification_id)
    if not n:
        raise HTTPException(404, "通知不存在")
    to = NotificationStatus.SEEN if body.event == "seen" else NotificationStatus.ACKNOWLEDGED
    return _run(lambda: transition_notification(session, n, to, f"patient:{encounter_id}"))


@router.post("/encounters/{encounter_id}/events")
def usage_event(encounter_id: str, body: S.UsageEventIn, session: Session = Depends(get_session)):
    enc = _enc(session, encounter_id)
    return _run(svc.record_event, session, enc, body.type, body.payload, body.client_ts)
